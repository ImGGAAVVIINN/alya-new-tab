pref('firstRun',true);
pref('firstRunDomain', 'freeaddon.com');

pref('bg_img','bg-01.jpg');
pref('bg_color','');
pref('bg_img_list', 40);
pref('frame_bg_list', 2);
pref('bg_color_gif', {});

pref('geodata','');
pref('units_weather','imperial');
pref('date_format','{{m}}.{{d}}.{{y}}');
pref('time_format','12h');
pref('ver_reset_clicked_options', '');
pref('ver_update_ignore', '0.1.9.3 - 0.1.9.5');
pref('ver_update_major', '0.1.9.6');
pref('ver_update_minor', '');
